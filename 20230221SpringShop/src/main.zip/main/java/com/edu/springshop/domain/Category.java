package com.edu.springshop.domain;

import lombok.Data;

@Data
public class Category {
	private int category_idx;
	private String category_name;
	
}