package com.edu.springboard.model.gallery;

import java.util.List;

import com.edu.springboard.domain.Photo;

public class HibernatePhotoDAO implements PhotoDAO{

	@Override
	public List selectAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Photo select(int photo_idx) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void insert(Photo photo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteByGallery(int gallery_idx) {
		// TODO Auto-generated method stub
		
	}

}
